package tn.esprit.pacelearning.services;

import tn.esprit.pacelearning.models.Don;
import tn.esprit.pacelearning.models.Donateur;
import tn.esprit.pacelearning.utils.MyDatabase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DonService implements Iservices{
    private Connection connection;
    public DonService(){
        connection = MyDatabase.getInstance().getConnection();
    }
    @Override
    public void ajouter(Object  o) throws SQLException {
        String req = "INSERT INTO Don(somme) VALUES('"+ Don.getSomme()+"')";
        Statement st = connection.createStatement();
        st.executeUpdate(req);


    }

    @Override
    public void modifier(Object o) throws SQLException {
        String req ="UPDATE Don SET somme = ?, idDonateur = ? WHERE idDon = ?";
        PreparedStatement ps = connection.prepareStatement(req);
        ps.setString(1,Don.getSomme());
        ps.setString(2, Don.getIdDonateur());
        ps.setInt(3, Don.getIdDon());
        ps.executeUpdate();

    }

    @Override
    public void supprimer(int id) throws SQLException {
        String req ="DELETE FROM Don WHERE idDon =?";
        PreparedStatement ps = connection.prepareStatement(req);
        ps.setInt(1,id);
        ps.executeUpdate();

    }

    @Override
    public List recuperer() throws SQLException {
        List<Don> dons = new ArrayList<>();
        String req = "SELECT * FROM Donateur ";
        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(req);
        while (rs.next()) {
            Don don = new Don();
            Don.setIdDon(rs.getInt("idDon"));
            Don.setSomme(rs.getString("somme"));
            Don.setIdDonateur(rs.getString("idDoanteur"));
            dons.add(don);

        }
        return dons;
    }}
