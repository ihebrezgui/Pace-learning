package tn.esprit.pacelearning.models;


public class Don {
    private static int somme;
    private static int idDon;
    private static int idDonateur;

    public Don(int somme, int idDon, int idDonateur) {
        this.somme  = somme;
        this.idDon = idDon;
        this.idDonateur = idDonateur;

    }
    public Don() {
        this.somme  = somme;
        this.idDonateur = idDonateur;

    }

    public static String getSomme() {
        return somme;
    }

    public  int getIdDon() {
        return idDon;
    }

    public  String getIdDonateur() {
        return idDonateur;
    }

    public  void setSomme(int somme) {
        Don.somme = somme;
    }

    public  void setIdDon(int idDon) {
        Don.idDon = idDon;
    }

    public  void setIdDonateur(int idDonateur) {
        Don.idDonateur = idDonateur;
    }
    public String toString() {
        return "Don{" +
                "id=" + idDon+
                ", somme='" + somme + '\'' +
                ", idDonateur='" + idDonateur + '\'' +
                '}';
    }
}
